# SUTRA GOLD+ Women's Care Landing Page

A responsive React + Vite landing page scaffold based on the product photos supplied by the owner.

## Run locally
1. Install Node.js (LTS).
2. Extract this folder.
3. Open a terminal in this folder and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL printed by Vite.
5. Create a production build with `npm run build`.

## Files
- `src/App.jsx` — page sections and footer
- `src/components/Header.jsx` — navigation header
- `src/components/Hero.jsx` — hero section
- `src/components/OrderSection.jsx` — enquiry form UI
- `src/data.js` — product details, ingredients, use notes
- `src/styles.css` — responsive styling
- `public/images/sutra-gold-women.jpg` — supplied product photo
- `index.html`, `package.json`, `vite.config.js` — app setup

## Before publishing — important
- **The form is a front-end demo only.** It does not send or save orders. Connect it to the actual CRM/order API, add server-side validation, spam protection, and test it end-to-end before accepting customers.
- MRP `₹2,999`, marketer, customer care, batch, manufacturing/expiry dates and licence are transcribed from the supplied photos. Verify every detail against the physical product and applicable records.
- The photos appear to show two different front-label designs for the same product. Confirm the final approved packaging and replace `public/images/sutra-gold-women.jpg` if needed.
- Verify the full ingredient list from the physical label; the photos are not perfectly legible.
- Do not publish a selling price, discount, testimonials, clinical outcomes, intimate-health claims, or safety/efficacy claims unless appropriately substantiated and legally reviewed.
- Confirm product classification, licence/label requirements, applicable advertising rules, privacy policy, terms, returns/refunds, shipping and contact details before launch.
- The product photo is a supplied hand-held photograph; use approved high-quality pack shots for the final public site.
- No payment gateway, WhatsApp order integration, Meta Pixel, analytics, or CRM connection is included yet.
