import React from "react";
import { ArrowUpRight, Check, Droplets, Leaf, ShieldAlert, Sparkles } from "lucide-react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import OrderSection from "./components/OrderSection";
import { product, ingredients, usage } from "./data";

function SectionHeading({ kicker, title, accent, text }) {
  return <div className="section-heading"><div className="eyebrow"><span /> {kicker}</div><h2>{title}<br /><em>{accent}</em></h2>{text && <p>{text}</p>}</div>;
}

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <section className="intro-section section-pad" id="about">
          <div className="intro-image">
            <img src="/images/sutra-gold-women.jpg" alt="SUTRA GOLD+ क्रीम की बोतल और पैकेजिंग" />
            <span className="image-caption">SUTRA GOLD+ / WOMEN'S CARE</span>
          </div>
          <div className="intro-content">
            <div className="eyebrow"><span /> PRODUCT DETAILS</div>
            <h2>जानकारी स्पष्ट।<br /><em>चुनाव आपका।</em></h2>
            <p>यह पेज उत्पाद की पैकेजिंग पर उपलब्ध जानकारी को सरल तरीके से प्रस्तुत करता है। खरीदने या उपयोग करने से पहले सामग्री, निर्देश, निर्माता और लाइसेंस संबंधी विवरण जाँचें।</p>
            <div className="detail-list">
              <div><span className="detail-icon"><Droplets /></span><span><b>पैक साइज</b><small>{product.packSize} — पैकेज पर अंकित</small></span></div>
              <div><span className="detail-icon"><Leaf /></span><span><b>उत्पाद प्रकार</b><small>बाहरी उपयोग के लिए क्रीम</small></span></div>
              <div><span className="detail-icon"><ShieldAlert /></span><span><b>उपयोग से पहले</b><small>लेबल निर्देश और सावधानियाँ पढ़ें</small></span></div>
            </div>
            <a className="text-link dark-link" href="#how-to-use">उपयोग संबंधी सावधानियाँ <ArrowUpRight size={17} /></a>
          </div>
        </section>
        <section className="ingredients-section section-pad" id="ingredients">
          <SectionHeading kicker="INGREDIENTS" title="जानें इसमें क्या है" accent="सामग्री की सूची" text="नीचे दी गई सामग्री आपके भेजे गए पैकेज की तस्वीरों से पढ़ी गई है। छपाई धुंधली होने के कारण अंतिम सूची को वास्तविक लेबल से सत्यापित करें।" />
          <div className="ingredient-grid">
            {ingredients.map((item, i) => <div className="ingredient-card" key={item}><span className="ingredient-number">0{i + 1}</span><span className="ingredient-icon"><Leaf size={22} /></span><b>{item}</b><span className="ingredient-check"><Check size={15} /></span></div>)}
          </div>
          <p className="fine-print">सामग्री की सूची पैकेज की उपलब्ध तस्वीरों के आधार पर तैयार की गई है; यह पूर्ण या स्वतंत्र रूप से प्रमाणित सूची नहीं है।</p>
        </section>
        <section className="usage-section section-pad" id="how-to-use">
          <div className="usage-copy">
            <div className="eyebrow"><span /> IMPORTANT INFORMATION</div>
            <h2>उपयोग से पहले<br /><em>ये बातें जानें।</em></h2>
            <p>अंतरंग त्वचा संवेदनशील होती है। किसी भी क्रीम को इस्तेमाल करने से पहले लेबल के निर्देशों का पालन करें और असुविधा होने पर उपयोग रोक दें।</p>
          </div>
          <div className="usage-list">{usage.map((item, i) => <div className="usage-item" key={item}><span>{String(i + 1).padStart(2, "0")}</span><p>{item}</p><Check size={17} /></div>)}</div>
        </section>
        <section className="disclaimer-strip"><Sparkles size={20} /><p><b>महत्वपूर्ण:</b> यह पेज किसी चिकित्सकीय परिणाम या बीमारी के उपचार का दावा नहीं करता। अंतरंग स्वास्थ्य संबंधी समस्या हो तो योग्य डॉक्टर से सलाह लें।</p></section>
        <OrderSection />
      </main>
      <footer className="site-footer">
        <a className="brand footer-brand" href="#home"><span className="brand-mark"><Leaf size={19} /></span><span><b>SUTRA GOLD+</b><small>WOMEN'S CARE</small></span></a>
        <div className="footer-business"><b>{product.marketer}</b><span>{product.address}</span><span>Customer Care: {product.customerCare}</span></div>
        <div className="footer-meta"><span>MRP ₹{product.mrp.toLocaleString("en-IN")} (पैकेज पर अंकित)</span><span>Batch: {product.batch}</span><span>Mfg: {product.mfgDate} · Exp: {product.expiryDate}</span></div>
        <p className="copyright">© {new Date().getFullYear()} SUTRA GOLD+. सभी अधिकार सुरक्षित। लाइव करने से पहले उत्पाद और कानूनी विवरण सत्यापित करें।</p>
      </footer>
      <a className="mobile-sticky-cta" href="#order">प्रोडक्ट की जानकारी लें <ArrowUpRight size={18} /></a>
    </>
  );
}