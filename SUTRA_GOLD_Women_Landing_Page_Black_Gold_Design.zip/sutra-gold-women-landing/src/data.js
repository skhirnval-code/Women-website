export const product = {
  name: "SUTRA GOLD+",
  subtitle: "Women's Care Cream",
  packSize: "50 gm",
  mrp: 2999,
  // Confirm the actual selling price before publishing.
  sellingPrice: null,
  marketer: "Mandeep Enterprises",
  address: "Amritsar, Punjab 143001",
  customerCare: "8284852859",
  manufacturer: "Family Life Herbal, Prem Nagar, Jaipur, Rajasthan",
  batch: "MN PCRM-0032",
  mfgDate: "Oct 2026",
  expiryDate: "Mar 2028",
  licence: "RJ 1104-AYU",
};

export const ingredients = [
  "Purified Water",
  "Aloe Vera Extract",
  "Glycerin",
  "Shea Butter",
  "Lodhra Extract",
  "Shatavari Extract",
  "Ashoka Extract",
  "Manjistha Extract",
  "Vitamin E",
];

export const usage = [
  "केवल बाहरी उपयोग के लिए।",
  "उपयोग से पहले पैकेज पर दिए गए निर्देश पढ़ें।",
  "आँखों, टूटी या irritated त्वचा से संपर्क से बचाएँ।",
  "जलन, लालिमा या असुविधा होने पर उपयोग बंद करें।",
  "गर्भवती या स्तनपान कराने वाली महिलाएँ पहले डॉक्टर से सलाह लें।",
];