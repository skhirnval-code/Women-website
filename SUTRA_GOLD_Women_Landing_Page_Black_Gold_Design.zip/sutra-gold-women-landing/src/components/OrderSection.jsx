import React, { useState } from "react";
import { CheckCircle2, Send } from "lucide-react";
import { product } from "../data";

export default function OrderSection() {
  const [form, setForm] = useState({ name: "", phone: "", pincode: "", city: "", address: "" });
  const [message, setMessage] = useState("");
  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  function submit(e) {
    e.preventDefault();
    // Demo-only: no order is sent to a server. Connect your CRM/order API before launch.
    const summary = [
      "SUTRA GOLD+ Women's Care Cream — order enquiry",
      `Name: ${form.name}`, `Phone: ${form.phone}`, `PIN: ${form.pincode}`,
      `City/State: ${form.city}`, `Address: ${form.address}`,
      "Please confirm product price, availability and delivery before accepting order."
    ].join("\\n");
    setMessage("फॉर्म तैयार है। अभी कोई ऑर्डर सर्वर पर सबमिट नहीं हुआ है। लाइव ऑर्डर के लिए CRM/API कनेक्शन आवश्यक है।");
    setForm({ name: "", phone: "", pincode: "", city: "", address: "" });
    // Make the prepared message available for later integration without exposing customer data in the UI.
    console.info("Connect this payload to your order API:", summary);
  }

  return (
    <section className="order-section section-pad" id="order">
      <div className="order-intro">
        <div className="eyebrow"><span /> PRODUCT ENQUIRY</div>
        <h2>प्रोडक्ट की जानकारी<br /><em>पाने के लिए संपर्क करें।</em></h2>
        <p>अपनी जानकारी भरें। लाइव वेबसाइट पर इस फॉर्म को आपके CRM/ऑर्डर सिस्टम से जोड़ना होगा।</p>
        <div className="price-card">
          <small>पैकेज पर अंकित MRP</small>
          <strong>₹{product.mrp.toLocaleString("en-IN")}</strong>
          <span>वर्तमान बिक्री मूल्य और उपलब्धता प्रकाशित करने से पहले पुष्टि करें।</span>
        </div>
      </div>
      <form className="order-form" onSubmit={submit}>
        <h3>अपनी जानकारी भरें</h3>
        <p className="form-note">* सभी आवश्यक फ़ील्ड भरें</p>
        <label>पूरा नाम<input required name="name" value={form.name} onChange={update} placeholder="आपका नाम" autoComplete="name" /></label>
        <label>मोबाइल नंबर<input required name="phone" value={form.phone} onChange={update} placeholder="10 अंकों का मोबाइल नंबर" inputMode="numeric" pattern="[6-9][0-9]{9}" maxLength="10" autoComplete="tel" /></label>
        <div className="form-row">
          <label>पिनकोड<input required name="pincode" value={form.pincode} onChange={update} placeholder="6 अंकों का PIN" inputMode="numeric" pattern="[0-9]{6}" maxLength="6" autoComplete="postal-code" /></label>
          <label>शहर / राज्य<input required name="city" value={form.city} onChange={update} placeholder="शहर, राज्य" autoComplete="address-level2" /></label>
        </div>
        <label>पूरा पता<textarea required name="address" value={form.address} onChange={update} placeholder="मकान नंबर, गली, क्षेत्र" rows="3" autoComplete="street-address" /></label>
        <button className="button button-primary submit-button" type="submit">जानकारी सबमिट करें <Send size={17} /></button>
        <p className="privacy-note"><CheckCircle2 size={15} /> आपकी जानकारी का उपयोग केवल अनुरोध के संदर्भ में करें। लाइव साइट पर गोपनीयता नीति जोड़ें।</p>
        {message && <p className="form-status" role="status">{message}</p>}
      </form>
    </section>
  );
}