import React from "react";
import { ArrowDown, ShieldCheck, Sprout } from "lucide-react";
import { product } from "../data";

export default function Hero() {
  return (
    <section className="hero" id="home">
      <div className="hero-glow" />
      <div className="hero-copy">
        <div className="eyebrow"><span /> PERSONAL CARE • 50 GM</div>
        <h1>आपकी पर्सनल केयर,<br /><em>आपके अपने</em> अंदाज़ में।</h1>
        <p className="hero-description">
          SUTRA GOLD+ Women's Care Cream के बारे में जानें—सामग्री,
          उपयोग संबंधी जानकारी और जरूरी सावधानियाँ एक ही जगह।
        </p>
        <div className="hero-actions">
          <a className="button button-primary" href="#about">प्रोडक्ट देखें <ArrowDown size={17} /></a>
          <a className="text-link" href="#ingredients">सामग्री पढ़ें <span>↗</span></a>
        </div>
        <div className="hero-trust">
          <span><Sprout size={17} /> सामग्री की जानकारी</span>
          <span><ShieldCheck size={17} /> जिम्मेदार उपयोग</span>
        </div>
      </div>
      <div className="hero-product">
        <img className="hero-photo" src="/images/sutra-gold-pair.jpg" alt="SUTRA GOLD+ Men's और Women's Care की बोतलें" />
      </div>
      <div className="hero-bottom"><span>01 / PRODUCT OVERVIEW</span><span>SCROLL TO EXPLORE ↓</span></div>
    </section>
  );
}