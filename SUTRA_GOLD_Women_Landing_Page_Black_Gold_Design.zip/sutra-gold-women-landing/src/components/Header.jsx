import React from "react";
import { Leaf, Menu } from "lucide-react";

export default function Header() {
  return (
    <header className="site-header">
      <a className="brand" href="#home" aria-label="SUTRA GOLD+ Home">
        <span className="brand-mark"><Leaf size={19} /></span>
        <span><b>SUTRA GOLD+</b><small>WOMEN'S CARE</small></span>
      </a>
      <nav className="desktop-nav">
        <a href="#about">प्रोडक्ट जानकारी</a>
        <a href="#ingredients">सामग्री</a>
        <a href="#how-to-use">उपयोग व सावधानी</a>
      </nav>
      <a className="header-cta" href="#order">ऑर्डर जानकारी <span>↗</span></a>
      <button className="mobile-menu" aria-label="मेनू"><Menu size={22} /></button>
    </header>
  );
}